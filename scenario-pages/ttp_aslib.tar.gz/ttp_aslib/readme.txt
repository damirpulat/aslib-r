Original data at: http://cs.adelaide.edu.au/~optlog/research/combinatorial.php

Reference for peformance data:

Hayden Faulkner, Sergey Polyakovskiy, Tom Schultz, and Markus Wagner. 2015. Approximate Approaches to the Traveling Thief Problem. In Proceedings of the 2015 Annual Conference on Genetic and Evolutionary Computation (GECCO '15), Sara Silva (Ed.). ACM, New York, NY, USA, 385-392. DOI=http://dx.doi.org/10.1145/2739480.2754716

Reference for instances:

Sergey Polyakovskiy, Mohammad Reza Bonyadi, Markus Wagner, Zbigniew Michalewicz, and Frank Neumann. 2014. A comprehensive benchmark set and heuristics for the traveling thief problem. In Proceedings of the 2014 Annual Conference on Genetic and Evolutionary Computation (GECCO '14). ACM, New York, NY, USA, 477-484. DOI=http://dx.doi.org/10.1145/2576768.2598249

Converted to ASlib by: Marius Lindauer


